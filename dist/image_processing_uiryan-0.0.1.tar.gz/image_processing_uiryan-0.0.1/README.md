# image_processing_uiryan

Description. 
The package image_processing_uiryan is used to:
	Processing:
		- Histogram matching
		- Structural similarity
		- Resize image
	Ultils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_uiryan

```bash
pip install image_processing_uiryan
```

## Author
I'm using this code as a trainee under Karine. Uiryan

## License
[MIT](https://choosealicense.com/licenses/mit/)